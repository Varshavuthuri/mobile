package com.example.app1;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity"; // Tag for logging
    private GridLayout gridLayout;
    private List<TextView> textViewList = new ArrayList<>();
    private Button btnOdd, btnEven, btnPrime, btnFibonacci;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize GridLayout and Buttons
        try {
            gridLayout = findViewById(R.id.gridLayout);
            btnOdd = findViewById(R.id.btnOdd);
            btnEven = findViewById(R.id.btnEven);
            btnPrime = findViewById(R.id.btnPrime);
            btnFibonacci = findViewById(R.id.btnFibonacci);

            // Populate GridLayout with numbers from 1 to 100
            addNumbersToGrid();

            // Set up button listeners for different rules
            btnOdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    highlightOddNumbers();
                }
            });

            btnEven.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    highlightEvenNumbers();
                }
            });

            btnPrime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    highlightPrimeNumbers();
                }
            });

            btnFibonacci.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    highlightFibonacciNumbers();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views", e);
        }
    }

    // Method to add numbers 1 to 100 in GridLayout
    private void addNumbersToGrid() {
        try {
            for (int i = 1; i <= 100; i++) {
                TextView textView = new TextView(this);
                textView.setText(String.valueOf(i));
                textView.setTextSize(18);
                textView.setGravity(Gravity.CENTER);
                textView.setPadding(20, 20, 20, 20);
                textView.setBackgroundColor(Color.LTGRAY);  // Default background color
                gridLayout.addView(textView);

                // Store reference to each TextView to modify them later
                textViewList.add(textView);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error adding numbers to grid", e);
        }
    }

    // Highlight odd numbers in the grid
    private void highlightOddNumbers() {
        resetGrid();
        try {
            for (int i = 0; i < textViewList.size(); i++) {
                int number = i + 1;
                if (number % 2 != 0) {
                    textViewList.get(i).setBackgroundColor(Color.YELLOW);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error highlighting odd numbers", e);
        }
    }

    // Highlight even numbers in the grid
    private void highlightEvenNumbers() {
        resetGrid();
        try {
            for (int i = 0; i < textViewList.size(); i++) {
                int number = i + 1;
                if (number % 2 == 0) {
                    textViewList.get(i).setBackgroundColor(Color.GREEN);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error highlighting even numbers", e);
        }
    }

    // Highlight prime numbers in the grid
    private void highlightPrimeNumbers() {
        resetGrid();
        try {
            for (int i = 0; i < textViewList.size(); i++) {
                int number = i + 1;
                if (isPrime(number)) {
                    textViewList.get(i).setBackgroundColor(Color.RED);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error highlighting prime numbers", e);
        }
    }

    // Highlight Fibonacci numbers in the grid
    private void highlightFibonacciNumbers() {
        resetGrid();
        try {
            List<Integer> fibonacciNumbers = generateFibonacciNumbers(100);
            for (int i = 0; i < textViewList.size(); i++) {
                int number = i + 1;
                if (fibonacciNumbers.contains(number)) {
                    textViewList.get(i).setBackgroundColor(Color.BLUE);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error highlighting Fibonacci numbers", e);
        }
    }

    // Helper method to check if a number is prime
    private boolean isPrime(int num) {
        if (num < 2) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    // Helper method to generate Fibonacci numbers up to a limit
    private List<Integer> generateFibonacciNumbers(int limit) {
        List<Integer> fibonacciNumbers = new ArrayList<>();
        int a = 0, b = 1;
        while (b <= limit) {
            fibonacciNumbers.add(b);
            int temp = a + b;
            a = b;
            b = temp;
        }
        return fibonacciNumbers;
    }

    // Reset all grid cells to default color
    private void resetGrid() {
        try {
            for (TextView textView : textViewList) {
                textView.setBackgroundColor(Color.LTGRAY);  // Reset to default color
            }
        } catch (Exception e) {
            Log.e(TAG, "Error resetting grid", e);
        }
    }

}

